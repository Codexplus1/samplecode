// This is google map api reworked into jQuery plugin that can be adapted to projects
// This jQuery plugin will calculate to locations and display direction on the Map
// This will be extended to have more functionality.
// it only reroute location with click event. 


(function($)
{
  $.fn.jstrackme = function(options){ 

    var cls = null;
    this.each(function(e)
    { 
      //initialize the class
      cls = new j();
    });
    return cls;
  }

//set up the class
  var j = (function()
    {
      function j()
      {
          /*
            ## do nothing class constructor
            ## needed if auto load methods are required
          */
      }
      j.prototype.app = null;
      j.prototype.initApp = function()
      {
          //start the Map class and initMap method
          this.app = new Map();
          this.app.initMap();
          
          /*
            keep class pointer 'this' in variable '$this' for accessibility within 
            inner methods scope.
          */
          var $this = this;
          //set timeout for map update
          setTimeout(function(){
              $this.updateMap($this.app);
          }, 5000);

          $this.setEvent($this.app);
      }

      j.prototype.setEvent = function(app)
      {
            var $this = this;
            google.maps.event.addListener(app.map, 'click', function(event) {
                //clearOverlays();//clear all markers                
                var lat = event.latLng.lat(), lng = event.latLng.lng();  
                var latlng = {"latitude":lat,"longitude":lng}            
                $(".current_position").val(JSON.stringify(latlng));

                //update map with click function
                $this.updateMap(app);
            });
      }

      j.prototype.updateMap = function(app)
      {
          /*
              Route update method
              Update destination with result from ajax 
          */
          var destination = new google.maps.LatLng(55.95083379430734, -3.3614730834960938);

          var stored_origin = $(".current_position").val();// new google.maps.LatLng(55.9748368, -3.245835);
          var stored_json_origin = $.parseJSON(stored_origin);
          var stored_origin_latlng = new google.maps.LatLng(stored_json_origin.latitude, stored_json_origin.longitude);          
          
          app.onChangeHandler(stored_origin_latlng, destination);
      }


    //return class object
    return j;

  }());

  function Super()
  {
      this.testData = function(data)
      {
          res = false;
          if(typeof data != "undefined" && data){
              res = true;
          }
          return res;
      }
  }

  function Map(app)
  {
    /*
      Map class extends Super Class
    */

      Super.call(this, app);
      Map.prototype = Object.create(Super.prototype);
      Map.prototype.constructor = Map;

      this.directionsService = new google.maps.DirectionsService;
      this.directionsDisplay = new google.maps.DirectionsRenderer;
      this.map = null;
      this.initMap = function() 
      {
          var $this = this;
          $this.map = new google.maps.Map(document.getElementById('map'), {
            zoom: 7,
            center: {lat: 55.95083379430734, lng: -3.3614730834960938}
          });

          $this.directionsDisplay.setMap($this.map);

          //Get my current position          
          this.getMyCurrentPosition();
      }


      this.addMarker = function(lat, lng) 
      {
              var xy = new google.maps.LatLng(lat, lng);
                  var marker = new google.maps.Marker({
                    position: xy,
                    map: map
                  });
                  return marker;
      }

      this.onChangeHandler = function(coordA, coordB) 
      {
            //where coordA and coordB is the cordinates of origin and destination
            this.calculateAndDisplayRoute(this.directionsService, this.directionsDisplay, coordA, coordB); 
      }

      this.calculateAndDisplayRoute = function(directionsService, directionsDisplay, a, b) 
      {
        //test data for null, undefined, ...
        if(this.testData(a) && this.testData(b))
        {
          var origin_lnglat = a, destination_lnglat = b;

            directionsService.route({
                origin: origin_lnglat, 
                destination: destination_lnglat,
                travelMode: 'DRIVING'
            }, 
            function(response, status) 
            {
                if (status === 'OK') {
                  directionsDisplay.setDirections(response);
                } else {
                  window.alert('Request failed due to ' + status);
                }
            });

          }

      }

      this.showPosition = function(position) 
      {
        //store current position in a hidden form field
          var current_position = {"latitude":position.coords.latitude,"longitude":position.coords.longitude};
          $(".current_position").val(JSON.stringify(current_position));
      }

      this.getMyCurrentPosition = function()
      {          
          //test if navigator is supported
          if (navigator.geolocation){
              //get current position
              navigator.geolocation.getCurrentPosition(this.showPosition);
          }
      }
  }
//end Map Class


  })
(jQuery)

  